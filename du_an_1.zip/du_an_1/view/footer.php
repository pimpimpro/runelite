<script src="JS/main.js"></script>

<footer class="footer">
  <div class="footer-row">
<div class="footer-col">
  <h3>TIN TỨC & SỰ KIỆN</h3>
  <ul class="list-unstyled">
    <li><a href="#">Tin hoạt động</a></li>
    <li><a href="#">Xác thực sản phẩm chính hãng</a></li>
    <li><a href="#">Địa điểm bán hàng</a></li>
    <li><a href="#">Khuyến mại HOT</a></li>
  </ul>
</div>
<div class="footer-col">
  <h3>VỀ RUNELITE</h3>
              <ul class="list-unstyled">
                <li><a href="#">Thông điệp của Chủ tịch HĐQT</a></li>
                <li><a href="#">Cơ cấu tổ chức</a></li>
                <li><a href="#">Bí quyết - Meo vật</a></li>
                <li><a href="#">Tổn thưởng thức</a></li>
                <li><a href="#">Chính sách bảo hành</a></li>
                <li><a href="#">Liên he</a></li>
              </ul>
</div>
<div class="footer-col">
  <h3>SẢN PHẨM</h3>
  <ul class="list-unstyled">
    <li><a href="#">Máy lọc nước</a></li>
    <li><a href="#">Thiết bị nhà bếp</a></li>
    <li><a href="#">Điện tử Điện lạnh</a></li>
    <li><a href="#">Điện dân dụng</a></li>
    <li><a href="#">Thiết bị điện công nghiệp</a></li>
    <li><a href="#">Cửa chống cháy</a></li>
  </ul>
</div>
  </div>
  <div class="footer-row-1">
    <div class="footer-col-1">
      <h2>HỖ TRỢ KHÁCH HÀNG</h2>
      <ul >
        <li class="icon">
            <img src="image/youtube.png" alt="" srcset=""  >
            <img src="image/instagram.png" alt="" srcset=""  >
            <img src="image/facebook.png" alt="" srcset=""  >
        </li>
        <li >
            <img src="image/placeholder.png" alt="" srcset="" style="width: 30px; height: 30px;">
            <a href="#">Địa Chỉ: Ngõ 56 Phương Canh</a>
        </li>
    </div>
  </div>
  <div class="footer-row">
    <p>Copyright © 2023 Sunhouse</p>
  </div>
</footer>